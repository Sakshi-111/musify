
import { Item } from "./Item"
export const Items =({fn,allItems})=>{
    return(
        <>
            {allItems.map((currentItem,index) => 
            <Item fn={fn} key={index} item={currentItem}/>)}
        </>
    )
}