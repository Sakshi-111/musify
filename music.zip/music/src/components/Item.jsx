import { useState } from "react";
export const Item= ({fn, item})=>{
    console.log(item);
    const [playerFlag,setPlayerFlag ]=useState(false);
    
    const showPlayer=()=>
   { fn(true, item);

}

    return(
        <div className="row">
            <div className="col-2" style={{color:'white' }}>
                <img src={item.artworkUrl100}/>
                
            </div>
            <div className="col-6" style={{color:'white',
                                           border:'solid green' 
                                           }}>
            {item.artistName}{item.trackName}
            </div>'
            <div className="col-4" style={{color:'white', 'margin-bottom':35 ,'margin-top':10 }}>
            <button onClick={showPlayer} className='btn btn-primary' style={{backgroundColor:'brown'}}>
            <i class="fa-solid fa-play"></i> Play

            </button>
            </div>


   
    </div>
    )

}